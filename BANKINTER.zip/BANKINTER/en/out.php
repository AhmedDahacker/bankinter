<?php 
header("location: https://bankinter.com/banca"); 

?>