<?php
require "main.php";
header("location: en/index.php"); 
?>