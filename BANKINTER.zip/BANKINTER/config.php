<?php 
 


// ADMIN PANEL
define("PNL_USERNAME", "SADDAM");
define("PNL_PASSWORD", "12345");

//database info access for control panel
define('DB_HOST',	 "localhost");
define('DB_NAME',	 "vics");
define('DB_USER', 	 "root");
define('DB_PASS',	 "");
 
 
//if your host doesn't support local SQLite, then chnage it to off and put database information above
$local_db="on";
 


?>